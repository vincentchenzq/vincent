const getters = {
  taken : state => state.user.token,
  email : state => state.user.email
}
export  default getters
